package com.example.carrentalsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        //openSUV Page
        button = (Button) findViewById(R.id.btnSUV);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSUV();
            }
        });

        //openSedan Page
        button = (Button) findViewById(R.id.btnSedan);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSedan();
            }
        });

        //openSports Car Page
        button = (Button) findViewById(R.id.btnSportsCar);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSportsCar();
            }
        });
    }

    public void openSUV(){
        Intent intent = new Intent(this, SUV.class);
        startActivity(intent);
    }

    public void openSedan(){
        Intent intent = new Intent(this, SEDAN.class);
        startActivity(intent);
    }

    public void openSportsCar(){
        Intent intent = new Intent(this, SPORTS_CAR.class);
        startActivity(intent);
    }

}