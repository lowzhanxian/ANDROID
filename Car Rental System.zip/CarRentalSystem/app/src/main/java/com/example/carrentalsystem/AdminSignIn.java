package com.example.carrentalsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class AdminSignIn extends AppCompatActivity {
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sign_in);

        TextView name = (TextView) findViewById(R.id.adminName);
        TextView password = (TextView) findViewById(R.id.adminPassword);

        Button btnLogin = (Button) findViewById(R.id.btnLogin);

        //openMainActivity Page
        button = (Button) findViewById(R.id.btnBack);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openMainActivityPage();
            }
        });

        //admin Login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(name.getText().toString().equals("admin") && password.getText().toString().equals("1200")){
                    Toast.makeText(AdminSignIn.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    openAdminHomePage();
                }

                else if (name.getText().toString().equals("") && password.getText().toString().equals("")){
                    Toast.makeText(AdminSignIn.this, "Please Enter your name or password", Toast.LENGTH_SHORT).show();
                }

                else {
                    Toast.makeText(AdminSignIn.this, "Incorrect name or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void openAdminHomePage() {
        Intent intent = new Intent(this, adminHomePage.class);
        startActivity(intent);
    }

    private void openMainActivityPage() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}