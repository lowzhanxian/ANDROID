package com.example.carrentalsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Booking extends AppCompatActivity {
    final Calendar myCalendar= Calendar.getInstance();

    //Calender decleration
    EditText calendarS, calendarE;

    //PersonalInfo decleration
    EditText eName, eIC, eAge, eCountry, eContact;
    Button btnBook;

    FirebaseDatabase rootNode;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        //Calendar
        calendarS=(EditText) findViewById(R.id.startDate);
        calendarE=(EditText) findViewById(R.id.endDate);

        //Personal Info
        eName =  findViewById(R.id.name);
        eIC =  findViewById(R.id.ic);
        eAge = findViewById(R.id.age);
        eCountry =  findViewById(R.id.country);
        eContact =  findViewById(R.id.contact);

        btnBook = (Button) findViewById(R.id.btnBook);

        //store Data
        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //store data
                rootNode = FirebaseDatabase.getInstance();
                reference = rootNode.getReference("Customers");

                reference.setValue("First data");

                //openHomePage
                openHomepage();

            }
        });

        //Calendar Function
        DatePickerDialog.OnDateSetListener dateS =new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabelS();
            }
        };

        DatePickerDialog.OnDateSetListener dateE =new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabelE();
            }
        };

        //Show calendar
        calendarS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Booking.this,dateS,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        calendarE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Booking.this,dateE,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }

    private void openHomepage() {
        Intent intent = new Intent(this, HomePage.class);
        Toast.makeText(this, "Booking make Successfully", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }

    //update date in edit text
    private void updateLabelS(){
        String myFormat="MM/dd/yy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        calendarS.setText(dateFormat.format(myCalendar.getTime()));
    }

    private void updateLabelE(){
        String myFormat="MM/dd/yy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
        calendarE.setText(dateFormat.format(myCalendar.getTime()));
    }
}